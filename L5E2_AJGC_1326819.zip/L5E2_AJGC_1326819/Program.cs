﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L5E2_AJGC_1326819
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 2");
            Console.Write("Ingrese el número de día  ");

            if (int.TryParse(Console.ReadLine(), out int numeroDia))
            {
                if (numeroDia >= 1 && numeroDia <= 7)
                {
                    string diaSemana = "";

                    if (numeroDia == 1)
                    {
                        diaSemana = "lunes";
                        Console.ReadKey();
                    }
                    else if (numeroDia == 2)
                    {
                        diaSemana = "martes";
                        Console.ReadKey();
                    }
                    else if (numeroDia == 3)
                    {
                        diaSemana = "miércoles";
                        Console.ReadKey();
                    }
                    else if (numeroDia == 4)
                    {
                        diaSemana = "jueves";
                        Console.ReadKey();
                    }
                    else if (numeroDia == 5)
                    {
                        diaSemana = "viernes";
                        Console.ReadKey();
                    }
                    else if (numeroDia == 6)
                    {
                        diaSemana = "sábado";
                        Console.ReadKey();
                    }
                    else if (numeroDia == 7)
                    {
                        diaSemana = "domingo";
                        Console.ReadKey();
                    }

                    Console.WriteLine("DIA: " + diaSemana);
                }
                else
                {
                    Console.WriteLine("Error: El número a ingresar debe estar contenido entre 1 y 7");
                }
            }
            else
            {
                Console.WriteLine("Error: Ingrese un número válido.");
            }
            Console.ReadKey();

        }//CIERRE 3
    }//CIERRE 2
}//CIERRE 1
