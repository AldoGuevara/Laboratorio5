﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L5_AJGC_1326819
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Ejercicio 1");
            Console.Write("Número ENTERO: ");

            string input = Console.ReadLine();

            if (int.TryParse(input, out int numero))
            {
                if (numero > 0)
                {
                    Console.WriteLine("RESULTADO: El número es positivo.");
                    Console.ReadKey();
                }
                else if (numero < 0)
                {
                    Console.WriteLine("RESULTADO: El número es negativo.");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("RESULTADO: El número es cero.");
                    Console.ReadKey();
                }
            }
            else
            {
                Console.WriteLine("ERROR: Ingrese un número entero válido.");
                Console.ReadKey();
            }

            }//CIERRE 3 
    }//CIERRE 2
}//CIERRE 1
