﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T5_AJGC_1326819
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese 3 cantidades de dinero junto con la moneda (USD o GTQ):");

            List<decimal> cantidades = new List<decimal>();
            List<string> monedas = new List<string>();

            for (int i = 0; i < 3; i++)
            {
                Console.Write($"Cantidad {i + 1}: ");
                decimal cantidad;
                if (decimal.TryParse(Console.ReadLine(), out cantidad))
                {
                    Console.Write("Moneda (USD o GTQ): ");
                    string moneda = Console.ReadLine().ToUpper();

                    switch (moneda)
                    {
                        case "USD":
                            cantidades.Add(cantidad * 7.83M);
                            monedas.Add("GTQ");
                            Console.ReadKey();
                            break;
                        case "GTQ":
                            cantidades.Add(cantidad);
                            monedas.Add("GTQ");
                            Console.ReadKey();
                            break;
                        default:
                            Console.WriteLine("Error: La moneda debe ser USD o GTQ. Intente nuevamente.");
                            i--;
                            Console.ReadKey();
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Error: Ingrese una cantidad válida. Intente nuevamente.");
                    i--;
                    Console.ReadKey();
                }
            }

            cantidades.Sort();

            Console.WriteLine("Cantidades ordenadas en GTQ:");

            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine($"Cantidad {i + 1}: Q. {cantidades[i]:F2}");
                Console.ReadKey();
            }

        }
    }
}
