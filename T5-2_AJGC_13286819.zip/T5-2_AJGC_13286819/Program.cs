﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T5_2_AJGC_13286819
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Double descuento = 0;
            Console.WriteLine("Ingrese el monto gastado: ");
            Double monto= Convert.ToDouble(Console.ReadLine());


            Console.WriteLine("posee codigo de descuento (Escriba si o no ) ");
            string DescuentoSt=Console.ReadLine();

            switch (DescuentoSt)
            {
                case "si":

                    if (monto < 400)
                    {
                        Console.WriteLine("No hay descuento");
                    }
                    else
                    {
                        if (monto >= 400 && monto <= 1000)
                        {
                            Console.WriteLine("tiene descuento del 7% , Su monto total a apagar es de: ");
                            Console.WriteLine(descuento = monto * 0.12);
                        }
                        else
                        {
                            if (monto >= 1000 && monto <= 5000)
                            {
                                Console.WriteLine("tiene descuento del 10% , Su monto total a apagar es de: ");
                                Console.WriteLine(descuento = monto * 0.15);
                            }
                            else
                            {
                                if (monto >= 5000 && monto <= 15000)
                                {
                                    Console.WriteLine("tiene descuento del 15%, Su monto total a apagar es de:  ");
                                    Console.WriteLine(descuento = monto * 0.20);
                                }
                                else
                                {
                                    if (monto > 15000)
                                    {
                                        Console.WriteLine("tiene descuento del 25%, Su monto total a apagar es de:  ");
                                        Console.WriteLine(descuento = monto * 0.30);
                                    }

                                }

                            }
                        }
                    }

                    break;



                case "no":

                    if (monto < 400)
                    {
                        Console.WriteLine("No hay descuento");
                    }
                    else
                    {
                        if (monto >= 400 && monto <= 1000)
                        {
                            Console.WriteLine("tiene descuento del 7%, Su monto total a apagar es de:  ");
                            Console.WriteLine(descuento = monto * 0.07);
                        }
                        else
                        {
                            if (monto >= 1000 && monto <= 5000)
                            {
                                Console.WriteLine("tiene descuento del 10%, Su monto total a apagar es de:  ");
                                Console.WriteLine(descuento = monto * 0.10);
                            }
                            else
                            {
                                if (monto >= 5000 && monto <= 15000)
                                {
                                    Console.WriteLine("tiene descuento del 15%, Su monto total a apagar es de:  ");
                                    Console.WriteLine(descuento = monto * 0.15);
                                }
                                else
                                {
                                    if (monto > 15000)
                                    {
                                        Console.WriteLine("tiene descuento del 25%, Su monto total a apagar es de:  ");
                                        Console.WriteLine(descuento = monto * 0.25);
                                    }

                                }

                            }
                        }
                    }


                    break;
            }




           
            
            
            
           

            Console.ReadKey();
        }
    }
}
